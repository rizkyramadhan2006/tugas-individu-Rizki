<?php
if(isset($_POST['SUBMIT'])){
    session_start(){
        include 'db.php;

        $user = mysqli_real_escape_string($conn, $_POST['user']);
        $pass = mysqli_real_escape_string($conn, $_POST['pass');

        $cek = msqli_query($conn, "SELECT * FROM tb+admin WHERE username = '".$user."'AND password = '".$pass."'");
        if(msqli_num_rows($cek) > 0){
            $d = mysqli_fetch_objek($cek);
            $_SESSION['status_login'] =true;
            $_SESSION['a_global'] = $d;
            $_SESSION['id'] = $d->admin_id;
            echo '<script>window.location="ashboard.php"</script>';
        }else{
            echo '<script>alert("Username ataupassword anda salah")</script>';
        }
    }
    ?><br />